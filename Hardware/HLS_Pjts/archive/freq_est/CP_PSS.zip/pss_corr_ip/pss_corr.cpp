#include "math.h"
#include "pss_corr.h"

void copy_input(hls::stream<data_pkt> &IN_R, DTYPE& IN_R_temp, hls::stream<data_pkt> &IN_I,DTYPE& IN_I_temp, int& run, int &sample_num)
{
  data_pkt t_r,t_i;

  t_r = IN_R.read();
  t_i = IN_I.read();

  IN_R_temp = t_r.data;
  IN_I_temp = t_i.data;

  /* This will break the loop*/
  if(t_r.last == 1)
  {
    run = 0;
  }

  sample_num++;
}

void compute_threshold(DTYPE IN_R, DTYPE IN_I, DTYPE &OUT)
{
  static DTYPE mag_buff[SIZE_FFT] = {0};
  static DTYPE sum_mag = 0;

  DTYPE IN_R_pre, IN_I_pre, IN_abs_pre, IN_mag_temp;

  /*Pre scale the input*/
  IN_R_pre = PSS_THRESH*IN_R;
  IN_I_pre = PSS_THRESH*IN_I;

  IN_abs_pre = IN_R_pre*IN_R_pre + IN_I_pre*IN_I_pre;
  IN_mag_temp = IN_abs_pre - mag_buff[SIZE_FFT - 1];

  for(int i = SIZE_FFT-1; i > 0; i--)
  {
	mag_buff[i] = mag_buff[i-1];
  }
  mag_buff[0] = IN_abs_pre;


  sum_mag = sum_mag + IN_mag_temp;

  /*Apply lower limit*/
  if(sum_mag < LOW_THRESH)
  {
    OUT = sum_mag;
  }
  else
  {
    OUT = LOW_THRESH;
  }

}

void prep_buffer(DTYPE IN_R, DTYPE IN_I, DTYPE OUT_R[SIZE_FFT], DTYPE OUT_I[SIZE_FFT])
{
  for(int i = 0; i < SIZE_FFT - 1; i++)
  {
    OUT_R[i] = OUT_R[i+1];
    OUT_I[i] = OUT_I[i+1];
  }

  OUT_R[SIZE_FFT - 1] = IN_R;
  OUT_I[SIZE_FFT - 1] = IN_I;
}

void compute_pss_0(DTYPE IN_R_buff[SIZE_FFT], DTYPE IN_I_buff[SIZE_FFT], DTYPE &pss_rslt )
{
  DTYPE corr_sum = 0, ac, bd, acc_r = 0, acc_i = 0, temp;
  for(int i = 0; i < SIZE_FFT; i++)
  {
    // Complex conjugate and Multiply
	ac = IN_R_buff[i] * td_pss_0_real[i];
	bd = IN_I_buff[i] * td_pss_0_imag[i];
	acc_r += (ac + bd);
	temp = (IN_R_buff[i] + IN_I_buff[i]) * (td_pss_0_real[i]- td_pss_0_imag[i]);
	acc_i += (temp- ac + bd);
  }
  pss_rslt = sqrt(acc_r*acc_r + acc_i*acc_i);
}

void compute_pss_1(DTYPE IN_R_buff[SIZE_FFT], DTYPE IN_I_buff[SIZE_FFT], DTYPE &pss_rslt )
{
  DTYPE corr_sum = 0, ac, bd, acc_r = 0, acc_i = 0, temp;
  for(int i = 0; i < SIZE_FFT; i++)
  {
    // Complex conjugate and Multiply
	ac = IN_R_buff[i] * td_pss_1_real[i];
	bd = IN_I_buff[i] * td_pss_1_imag[i];
	acc_r += (ac + bd);
	temp = (IN_R_buff[i] + IN_I_buff[i]) * (td_pss_1_real[i]- td_pss_1_imag[i]);
	acc_i += (temp- ac + bd);
  }
  pss_rslt = sqrt(acc_r*acc_r + acc_i*acc_i);
}

void compute_pss_2(DTYPE IN_R_buff[SIZE_FFT], DTYPE IN_I_buff[SIZE_FFT], DTYPE &pss_rslt )
{
  DTYPE corr_sum = 0, ac, bd, acc_r = 0, acc_i = 0, temp;
  for(int i = 0; i < SIZE_FFT; i++)
  {
    // Complex conjugate and Multiply
	ac = IN_R_buff[i] * td_pss_2_real[i];
	bd = IN_I_buff[i] * td_pss_2_imag[i];
	acc_r += (ac + bd);
	temp = (IN_R_buff[i] + IN_I_buff[i]) * (td_pss_2_real[i]- td_pss_2_imag[i]);
	acc_i += (temp- ac + bd);
  }
  pss_rslt = sqrt(acc_r*acc_r + acc_i*acc_i);
}

void track_pss_peak(DTYPE pss_rslts_0, DTYPE pss_rslts_1, DTYPE pss_rslts_2, DTYPE thresh, DTYPE &curr_max, int &pss_id, int sample_num, int &index)
{
  bool is_valid_0 = false, is_valid_1 = false, is_valid_2 = false;

  if(pss_rslts_0 > thresh)
  {
    is_valid_0 = true;
  }

  if(pss_rslts_1 > thresh)
  {
    is_valid_1 = true;
  }

  if(pss_rslts_2 > thresh)
  {
    is_valid_2 = true;
  }


  if((is_valid_0)&&(pss_rslts_0 > curr_max))
  {
    curr_max = pss_rslts_0;
    pss_id = 0;
    index = sample_num;
  }

  if((is_valid_1)&&(pss_rslts_1 > curr_max))
  {
    curr_max = pss_rslts_1;
    pss_id = 1;
    index = sample_num;
  }

  if((is_valid_2)&&(pss_rslts_2 > curr_max))
  {
    curr_max = pss_rslts_2;
    pss_id = 2;
    index = sample_num;
  }
}

void write_output(DTYPE pss_rslts_0, DTYPE pss_rslts_1, DTYPE pss_rslts_2,int run,hls::stream<out_data_pkt> &OUT, int pss_id_temp, int peak_id_temp,int &pss_id, int &peak_index, int out_select )//,int &pss_id, int &peak_index, int pss_id_temp, int peak_id_temp)
{
  out_data_pkt t;
  t.keep = -1;
  t.strb = 1;
  t.last = 0;

  if(out_select == 0)
  {
    t.data = pss_rslts_0;
  }
  else if(out_select == 1)
  {
    t.data = pss_rslts_1;
  }
  else
  {
    t.data = pss_rslts_2;
  }

  if(run == 0)
  {
    t.last = 1;
    pss_id = pss_id_temp;
    peak_index = peak_id_temp;
  }


  OUT.write(t);

}

void pss_corr(hls::stream<data_pkt> &IN_R,hls::stream<data_pkt> &IN_I,hls::stream<out_data_pkt> &OUT, int &pss_id, int &peak_index, int out_select)
{
#pragma HLS INTERFACE axis port=IN_R
#pragma HLS INTERFACE axis port=IN_I
#pragma HLS INTERFACE axis port=OUT
#pragma HLS INTERFACE s_axilite port=pss_id bundle=data
#pragma HLS INTERFACE s_axilite port=peak_index bundle=data
#pragma HLS INTERFACE s_axilite port=out_select bundle=data
#pragma HLS INTERFACE s_axilite port=return bundle=control

  DTYPE IN_real,IN_imag,output, thresh,pss_rslt_0,pss_rslt_1,pss_rslt_2,curr_max = 0;
  DTYPE conj_rslt_r,conj_rslt_i;
  DTYPE avg_r,avg_i, avg_slot_r,avg_slot_i, freq;
  DTYPE IN_real_buff[SIZE_FFT] = {0},IN_imag_buff[SIZE_FFT] = {0};
  int run = 1, valid = 0, k = 0, sample_num = 0,pss_id_temp,peak_id_temp;

  pss_id = 3;
  peak_index = -1;
//#pragma HLS DATAFLOW
  while(run)
  {
    copy_input(IN_R,IN_real,IN_I,IN_imag,run, sample_num);
    compute_threshold(IN_real,IN_imag,thresh);
    prep_buffer(IN_real,IN_imag,IN_real_buff,IN_imag_buff);
    compute_pss_0(IN_real_buff,IN_imag_buff,pss_rslt_0);
    compute_pss_1(IN_real_buff,IN_imag_buff,pss_rslt_1);
    compute_pss_2(IN_real_buff,IN_imag_buff,pss_rslt_2);
    track_pss_peak(pss_rslt_0,pss_rslt_1,pss_rslt_2,thresh,curr_max,pss_id_temp,sample_num,peak_id_temp);
    write_output(pss_rslt_0,pss_rslt_1,pss_rslt_2,run,OUT,pss_id_temp,peak_id_temp,pss_id,peak_index,out_select);
  }
}


