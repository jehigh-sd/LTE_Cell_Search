// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// S_AXI_LITE
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of OUT_F
//        bit 31~0 - OUT_F[31:0] (Read/Write)
// 0x14 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XLTECELLSEARCH_S_AXI_LITE_ADDR_OUT_F_DATA 0x10
#define XLTECELLSEARCH_S_AXI_LITE_BITS_OUT_F_DATA 32

