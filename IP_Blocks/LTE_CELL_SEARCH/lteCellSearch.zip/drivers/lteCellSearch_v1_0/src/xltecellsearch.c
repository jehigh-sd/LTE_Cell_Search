// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xltecellsearch.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XLtecellsearch_CfgInitialize(XLtecellsearch *InstancePtr, XLtecellsearch_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->S_axi_lite_BaseAddress = ConfigPtr->S_axi_lite_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XLtecellsearch_Set_OUT_F(XLtecellsearch *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLtecellsearch_WriteReg(InstancePtr->S_axi_lite_BaseAddress, XLTECELLSEARCH_S_AXI_LITE_ADDR_OUT_F_DATA, Data);
}

u32 XLtecellsearch_Get_OUT_F(XLtecellsearch *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLtecellsearch_ReadReg(InstancePtr->S_axi_lite_BaseAddress, XLTECELLSEARCH_S_AXI_LITE_ADDR_OUT_F_DATA);
    return Data;
}

